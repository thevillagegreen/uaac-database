
Character types
---------------

.. toctree::
   :maxdepth: 2

   /docs/type/char/numericstring
   /docs/type/char/printablestring
   /docs/type/char/teletexstring
   /docs/type/char/t61string
   /docs/type/char/videotexstring
   /docs/type/char/ia5string
   /docs/type/char/graphicstring
   /docs/type/char/visiblestring
   /docs/type/char/iso646string
   /docs/type/char/generalstring
   /docs/type/char/universalstring
   /docs/type/char/bmpstring
   /docs/type/char/utf8string
